from collections import defaultdict
from typing import List, Dict, Tuple, Optional
from graph import Graph, Vertex, Edge
from graph_io import load_graph
from fast_colorref import (
    colour_refine_graphs,
    _build_neighbour_index,
    fast_colour_refine,
    Partition,
    get_colour_signature,
)
from permutation import Permutation, group_order, orbit_and_transversal
from preprocessing import (
    is_tree, is_forest, is_connected, find_components, tree_canonical_label,
    tree_automorphisms, reduce_twins,
)
from math import factorial

def _copy_graph(graph: Graph) -> Tuple[Graph, Dict[Vertex, Vertex]]:
    copy = Graph(directed=graph.directed, n=len(graph))
    copy_verts = list(copy.vertices)
    orig_verts = list(graph.vertices)
    index_of = {v: i for i, v in enumerate(orig_verts)}
    vertex_map = {orig_verts[i]: copy_verts[i] for i in range(len(orig_verts))}

    seen_edges: set = set()
    for e in graph.edges:
        ti, hi = index_of[e.tail], index_of[e.head]
        edge_key = (min(ti, hi), max(ti, hi))
        if edge_key not in seen_edges:
            seen_edges.add(edge_key)
            copy.add_edge(Edge(copy_verts[ti], copy_verts[hi]))

    return copy, vertex_map

class _BranchingContext:

    __slots__ = ("adj", "all_vertices", "verts_g", "verts_h",
                 "n_g", "base_colouring")

    def __init__(self, graph_g: Graph, graph_h: Graph, adj: Dict):
        self.adj = adj
        self.verts_g = list(graph_g)
        self.verts_h = list(graph_h)
        self.n_g = len(self.verts_g)
        self.all_vertices = self.verts_g + self.verts_h
        self.base_colouring = {v: v.degree for v in self.all_vertices}

    def refine_and_check(self, D: list, I: list):
        base = self.base_colouring
        depth = len(D)
        saved = []
        for i in range(depth):
            c = -(i + 1)
            saved.append((base[D[i]], base[I[i]]))
            base[D[i]] = c
            base[I[i]] = c

        partition = fast_colour_refine(self.all_vertices, self.adj, base)

        for i in range(depth):
            base[D[i]] = saved[i][0]
            base[I[i]] = saved[i][1]

        if not is_balanced_pair(self.verts_g, self.verts_h, partition):
            return None, 0
        if is_discrete_pair(self.verts_g, self.verts_h, partition):
            return partition, 1
        return partition, 2

def is_balanced_pair(verts_g: list, verts_h: list, partition: Partition) -> bool:
    vc = partition.vertex_colour
    counts_g: Dict[int, int] = {}
    for v in verts_g:
        c = vc[v]
        counts_g[c] = counts_g.get(c, 0) + 1
    for v in verts_h:
        c = vc[v]
        cnt = counts_g.get(c, 0) - 1
        if cnt < 0:
            return False
        counts_g[c] = cnt
    return all(c == 0 for c in counts_g.values())

def is_discrete_pair(verts_g: list, verts_h: list, partition: Partition) -> bool:
    vc = partition.vertex_colour
    n = len(verts_g)
    if n != len(verts_h):
        return False
    seen = set()
    for v in verts_g:
        c = vc[v]
        if c in seen:
            return False
        seen.add(c)
    return True

def _choose_branching_class(verts_g: list, verts_h: list,
                            partition: Partition
                            ) -> Tuple[List[Vertex], List[Vertex]]:
    vc = partition.vertex_colour
    colours_g: Dict[int, list] = {}
    colours_h: Dict[int, list] = {}

    for v in verts_g:
        c = vc[v]
        if c in colours_g:
            colours_g[c].append(v)
        else:
            colours_g[c] = [v]
    for v in verts_h:
        c = vc[v]
        if c in colours_h:
            colours_h[c].append(v)
        else:
            colours_h[c] = [v]

    best_colour = -1
    best_size = 0x7FFFFFFF

    for colour, vg in colours_g.items():
        lg = len(vg)
        if lg < 2:
            continue
        vh = colours_h.get(colour)
        if vh is None or len(vh) < 2:
            continue
        if lg < best_size:
            best_size = lg
            best_colour = colour

    cg = sorted(colours_g[best_colour], key=lambda v: v.degree, reverse=True)
    ch = sorted(colours_h[best_colour], key=lambda v: v.degree, reverse=True)
    return cg, ch

def _extract_bijection(verts_g: list, verts_h: list,
                       partition: Partition) -> Dict[Vertex, Vertex]:
    vc = partition.vertex_colour
    colour_to_h: Dict[int, Vertex] = {}
    for v in verts_h:
        colour_to_h[vc[v]] = v
    return {v: colour_to_h[vc[v]] for v in verts_g}

_ORBIT_PRUNE_MAX_VERTICES = 100

def _compute_h_aut_generators(graph_h: Graph, adj: Dict) -> Optional[List[Permutation]]:
    n = len(graph_h)
    if n > _ORBIT_PRUNE_MAX_VERTICES:
        return None
    if is_forest(graph_h):
        return None
    local_adj = _build_neighbour_index(list(graph_h))
    result = _count_aut_core(graph_h, local_adj, None, return_generators=True)
    if isinstance(result, int):
        return None
    order, generators = result
    if order <= 1 or not generators:
        return None
    return generators

def count_isomorphisms(graph_g: Graph,
                       graph_h: Graph,
                       D: List[Vertex],
                       I: List[Vertex],
                       adj: Dict,
                       gi_only: bool = False,
                       h_aut_generators: Optional[List[Permutation]] = None) -> int:
    ctx = _BranchingContext(graph_g, graph_h, adj)

    def _count(D: list, I: list,
               aut_gens: Optional[List[Permutation]]) -> int:
        partition, status = ctx.refine_and_check(D, I)
        if status == 0:
            return 0
        if status == 1:
            return 1

        cg, ch = _choose_branching_class(ctx.verts_g, ctx.verts_h, partition)
        x = cg[0]

        candidates = ch
        if aut_gens:
            ch_set = set(ch)
            seen: set = set()
            pruned = []
            for y in ch:
                if y in seen:
                    continue
                pruned.append(y)
                orb, _ = orbit_and_transversal(aut_gens, y)
                seen |= (orb & ch_set)
            candidates = pruned

        num = 0
        D.append(x)
        for y in candidates:
            I.append(y)
            next_gens = None
            if aut_gens:
                next_gens = [g for g in aut_gens if g(y) == y]
                if not next_gens:
                    next_gens = None
            num += _count(D, I, next_gens)
            I.pop()
            if gi_only and num > 0:
                D.pop()
                return num
        D.pop()
        return num

    return _count(list(D), list(I), h_aut_generators)

def _forest_automorphisms(graph: Graph) -> int:
    components = find_components(graph)

    label_groups: Dict[Tuple, List[List[Vertex]]] = defaultdict(list)
    for comp in components:
        label = tree_canonical_label(comp)
        label_groups[label].append(comp)

    total = 1
    for label, comps in label_groups.items():
        for comp in comps:
            total *= tree_automorphisms(comp)
        total *= factorial(len(comps))

    return total

def _component_graph(vertices: List[Vertex], parent: Graph) -> Graph:
    vset = set(vertices)
    sub = Graph(directed=parent.directed, n=len(vertices))
    sub_verts = list(sub.vertices)
    old_to_new = {vertices[i]: sub_verts[i] for i in range(len(vertices))}

    seen: set = set()
    for v in vertices:
        for e in v.incidence:
            other = e.other_end(v)
            if other in vset:
                ek = (min(id(e.tail), id(e.head)),
                      max(id(e.tail), id(e.head)))
                if ek not in seen:
                    seen.add(ek)
                    sub.add_edge(Edge(old_to_new[e.tail], old_to_new[e.head]))
    return sub

def _disconnected_automorphisms(graph: Graph, adj: Dict) -> int:
    components = find_components(graph)
    if len(components) == 1:
        return _count_aut_core(graph, adj, None)

    comp_graphs: List[Graph] = []
    comp_auts: List[int] = []
    for comp in components:
        sub = _component_graph(comp, graph)
        sub_adj = _build_neighbour_index(list(sub))
        if is_forest(sub):
            aut = _forest_automorphisms(sub)
        else:
            aut = _count_aut_core(sub, sub_adj, None)
        comp_graphs.append(sub)
        comp_auts.append(aut)

    assigned = [False] * len(comp_graphs)
    total = 1

    for i in range(len(comp_graphs)):
        if assigned[i]:
            continue
        assigned[i] = True
        group_count = 1
        total *= comp_auts[i]
        for j in range(i + 1, len(comp_graphs)):
            if assigned[j]:
                continue
            if len(comp_graphs[i]) != len(comp_graphs[j]):
                continue
            if len(comp_graphs[i].edges) != len(comp_graphs[j].edges):
                continue
            pair_adj = _build_neighbour_index(
                list(comp_graphs[i]) + list(comp_graphs[j])
            )
            if count_isomorphisms(comp_graphs[i], comp_graphs[j],
                                  [], [], pair_adj, gi_only=True) > 0:
                assigned[j] = True
                total *= comp_auts[j]
                group_count += 1
        total *= factorial(group_count)

    return total

def count_automorphisms(graph: Graph,
                        adj: Dict[Vertex, List[Vertex]]) -> int:
    if is_forest(graph):
        return _forest_automorphisms(graph)

    if not is_connected(graph):
        return _disconnected_automorphisms(graph, adj)

    reduced, aut_factor, pre_colouring = reduce_twins(graph)
    if len(reduced) < len(graph):
        reduced_adj = _build_neighbour_index(list(reduced))
        return aut_factor * _count_aut_core(reduced, reduced_adj, pre_colouring)

    return _count_aut_core(graph, adj, None)

def _count_aut_core(graph: Graph, adj: Dict,
                    pre_colouring: Optional[Dict],
                    return_generators: bool = False):
    graph_copy, vertex_map = _copy_graph(graph)

    for v in graph_copy:
        adj[v] = v.neighbours

    orig_verts = list(graph.vertices)
    copy_verts = list(graph_copy.vertices)
    copy_to_orig = {copy_verts[i]: orig_verts[i]
                    for i in range(len(orig_verts))}

    ctx = _BranchingContext(graph, graph_copy, adj)

    if pre_colouring is not None:
        for v in orig_verts:
            ctx.base_colouring[v] = pre_colouring.get(v, 0)
        for i, v in enumerate(copy_verts):
            ctx.base_colouring[v] = pre_colouring.get(orig_verts[i], 0)

    generating_set: List[Permutation] = []

    def _to_permutation(partition: Partition) -> Permutation:
        bijection = _extract_bijection(ctx.verts_g, ctx.verts_h, partition)
        return Permutation({v: copy_to_orig[bijection[v]] for v in orig_verts})

    D: list = []
    I: list = []

    def _update() -> None:
        partition, status = ctx.refine_and_check(D, I)
        if status == 0:
            return
        if status == 1:
            perm = _to_permutation(partition)
            if not perm.is_identity():
                generating_set.append(perm)
            return

        cg, ch = _choose_branching_class(ctx.verts_g, ctx.verts_h, partition)
        x = cg[0]
        x_copy = vertex_map[x]
        others = [y for y in ch if y is not x_copy]

        D.append(x)
        if x_copy in ch:
            I.append(x_copy)
            _update()
            I.pop()

        for y in others:
            I.append(y)
            _find_one(cg, ch)
            I.pop()
        D.pop()

    def _find_one(parent_cg, parent_ch) -> bool:
        partition, status = ctx.refine_and_check(D, I)
        if status == 0:
            return False
        if status == 1:
            perm = _to_permutation(partition)
            if perm.is_identity():
                return False
            generating_set.append(perm)
            return True

        cg, ch = _choose_branching_class(ctx.verts_g, ctx.verts_h, partition)
        x = cg[0]
        D.append(x)
        for y in ch:
            I.append(y)
            found = _find_one(cg, ch)
            I.pop()
            if found:
                D.pop()
                return True
        D.pop()
        return False

    _update()

    for v in copy_verts:
        adj.pop(v, None)

    if return_generators:
        return group_order(generating_set, orig_verts), generating_set
    return group_order(generating_set, orig_verts)

def _tree_equivalence_classes(graphs: List[Graph]) -> List[List[int]]:
    label_groups: Dict[Tuple, List[int]] = defaultdict(list)
    for i, G in enumerate(graphs):
        label = tree_canonical_label(list(G.vertices))
        label_groups[label].append(i)
    return sorted([sorted(g) for g in label_groups.values()],
                  key=lambda c: c[0])

def _are_isomorphic(graph_g: Graph, graph_h: Graph, adj: Dict,
                    h_aut_gens: Optional[List[Permutation]] = None) -> bool:
    if len(graph_g) != len(graph_h):
        return False
    if len(graph_g.edges) != len(graph_h.edges):
        return False
    return count_isomorphisms(graph_g, graph_h, [], [], adj,
                              gi_only=True,
                              h_aut_generators=h_aut_gens) > 0

def find_equivalence_classes(graphs: List[Graph],
                             adj: Dict[Vertex, List[Vertex]]
                             ) -> List[List[int]]:
    partition = colour_refine_graphs(graphs)
    sig_groups: Dict[Tuple, List[int]] = defaultdict(list)
    for i, G in enumerate(graphs):
        sig = get_colour_signature(G, partition)
        sig_groups[sig].append(i)

    equivalence_classes: List[List[int]] = []
    for indices in sig_groups.values():
        if len(indices) == 1:
            equivalence_classes.append(indices)
            continue

        remaining = set(indices)
        aut_cache: Dict[int, Optional[List[Permutation]]] = {}
        for i in indices:
            if i not in remaining:
                continue
            eq_class = [i]
            remaining.remove(i)
            to_remove = []
            for j in remaining:
                if j not in aut_cache:
                    aut_cache[j] = _compute_h_aut_generators(graphs[j], adj)
                if _are_isomorphic(graphs[i], graphs[j], adj,
                                   h_aut_gens=aut_cache[j]):
                    eq_class.append(j)
                    to_remove.append(j)
            for j in to_remove:
                remaining.remove(j)
            equivalence_classes.append(sorted(eq_class))

    return sorted(equivalence_classes, key=lambda c: c[0])

def solve(filename: str) -> None:
    name = filename.rsplit("/", 1)[-1].rsplit(".", 1)[0]
    do_gi = "GI" in name
    do_aut = "Aut" in name

    if not do_gi and not do_aut:
        if filename.endswith(".gr"):
            do_aut = True
        else:
            do_gi = True

    is_single = filename.endswith(".gr")

    if is_single:
        with open(filename, "r") as f:
            graph = load_graph(f, graph_class=Graph, read_list=False)
        adj = _build_neighbour_index(list(graph))
        aut = count_automorphisms(graph, adj)
        print(f"Number of automorphisms: {aut}")
        return

    with open(filename, "r") as f:
        graphs = load_graph(f, graph_class=Graph, read_list=True)

    all_verts = [v for G in graphs for v in G]
    adj = _build_neighbour_index(all_verts)

    all_trees = all(is_tree(G) for G in graphs)

    if do_gi and not do_aut:
        if all_trees:
            classes = _tree_equivalence_classes(graphs)
        else:
            classes = find_equivalence_classes(graphs, adj)
        print("Sets of isomorphic graphs:")
        for eq_class in classes:
            print(eq_class)

    elif do_aut and not do_gi:
        print("Number of automorphisms for each graph:")
        for i, G in enumerate(graphs):
            local_adj = _build_neighbour_index(list(G))
            aut = count_automorphisms(G, local_adj)
            print(f"{i}: {aut}")

    else:
        if all_trees:
            classes = _tree_equivalence_classes(graphs)
        else:
            classes = find_equivalence_classes(graphs, adj)
        print("Sets of isomorphic graphs with automorphisms:")
        for eq_class in classes:
            rep = eq_class[0]
            local_adj = _build_neighbour_index(list(graphs[rep]))
            aut = count_automorphisms(graphs[rep], local_adj)
            print(f"{eq_class}: {aut}")

if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("Usage: python branching.py <graph_file.grl|.gr>")
        sys.exit(1)
    solve(sys.argv[1])
