from collections import defaultdict, deque
from math import factorial
from typing import Dict, List, Optional, Set, Tuple
from graph import Graph, Vertex

def find_components(graph: Graph) -> List[List[Vertex]]:
    visited: Set[Vertex] = set()
    components: List[List[Vertex]] = []

    for start in graph:
        if start in visited:
            continue
        component: List[Vertex] = []
        queue: deque = deque([start])
        visited.add(start)
        while queue:
            v = queue.popleft()
            component.append(v)
            for u in v.neighbours:
                if u not in visited:
                    visited.add(u)
                    queue.append(u)
        components.append(component)

    return components

def is_connected(graph: Graph) -> bool:
    if len(graph) == 0:
        return True
    components = find_components(graph)
    return len(components) == 1

def is_tree(graph: Graph) -> bool:
    n = len(graph)
    if n == 0:
        return True
    return is_connected(graph) and len(graph.edges) == n - 1

def is_forest(graph: Graph) -> bool:
    components = find_components(graph)
    n = len(graph)
    m = len(graph.edges)
    return m == n - len(components)

def _find_center(vertices: List[Vertex]) -> List[Vertex]:
    if len(vertices) <= 2:
        return list(vertices)

    vertex_set = set(vertices)
    degree: Dict[Vertex, int] = {}
    for v in vertex_set:
        degree[v] = sum(1 for u in v.neighbours if u in vertex_set)

    remaining = set(vertex_set)
    leaves = [v for v in remaining if degree[v] <= 1]

    while len(remaining) > 2:
        new_leaves: List[Vertex] = []
        for leaf in leaves:
            remaining.discard(leaf)
            for u in leaf.neighbours:
                if u in remaining:
                    degree[u] -= 1
                    if degree[u] == 1:
                        new_leaves.append(u)
        leaves = new_leaves

    return list(remaining)

def ahu_label(root: Vertex, parent: Optional[Vertex],
              vertex_set: Set[Vertex]) -> Tuple:
    children_labels = []
    for child in root.neighbours:
        if child != parent and child in vertex_set:
            children_labels.append(ahu_label(child, root, vertex_set))
    return tuple(sorted(children_labels))

def tree_canonical_label(vertices: List[Vertex]) -> Tuple:
    vertex_set = set(vertices)
    centers = _find_center(vertices)

    if len(centers) == 1:
        return ahu_label(centers[0], None, vertex_set)

    label_a = ahu_label(centers[0], None, vertex_set)
    label_b = ahu_label(centers[1], None, vertex_set)
    return min(label_a, label_b)

def tree_automorphisms(vertices: List[Vertex]) -> int:
    vertex_set = set(vertices)
    centers = _find_center(vertices)

    def _count_rooted(root: Vertex, parent: Optional[Vertex]) -> Tuple[int, Tuple]:
        children_data: List[Tuple[int, Tuple]] = []
        for child in root.neighbours:
            if child != parent and child in vertex_set:
                children_data.append(_count_rooted(child, root))

        label_groups: Dict[Tuple, int] = defaultdict(int)
        aut = 1
        for child_aut, child_label in children_data:
            aut *= child_aut
            label_groups[child_label] += 1

        for count in label_groups.values():
            aut *= factorial(count)

        label = tuple(sorted(child_label for _, child_label in children_data))
        return aut, label

    if len(centers) == 1:
        aut, _ = _count_rooted(centers[0], None)
        return aut

    aut_a, label_a = _count_rooted(centers[0], centers[1])
    aut_b, label_b = _count_rooted(centers[1], centers[0])
    total = aut_a * aut_b

    if label_a == label_b:
        total *= 2

    return total

def find_twin_groups(graph: Graph) -> Tuple[List[Set[Vertex]], List[Set[Vertex]]]:
    false_sig: Dict[frozenset, List[Vertex]] = defaultdict(list)
    true_sig: Dict[frozenset, List[Vertex]] = defaultdict(list)

    for v in graph:
        nbrs = frozenset(v.neighbours)
        false_sig[nbrs].append(v)
        true_sig[nbrs | {v}].append(v)

    false_groups = [set(g) for g in false_sig.values() if len(g) >= 2]
    true_groups = [set(g) for g in true_sig.values() if len(g) >= 2]

    return true_groups, false_groups

def reduce_twins(graph: Graph) -> Tuple[Graph, int, Dict]:
    from graph import Edge

    vertices = list(graph.vertices)
    n = len(vertices)

    idx = {v: i for i, v in enumerate(vertices)}
    adj_sets: List[Set[int]] = [set() for _ in range(n)]
    for e in graph.edges:
        ti, hi = idx[e.tail], idx[e.head]
        adj_sets[ti].add(hi)
        adj_sets[hi].add(ti)

    alive = set(range(n))
    colour = [0] * n
    next_colour = 1
    aut_factor = 1

    type_size_to_colour: Dict[Tuple, int] = {}
    round_num = 0

    changed = True
    while changed:
        round_num += 1
        changed = False

        false_sig: Dict[Tuple, List[int]] = defaultdict(list)
        for i in alive:
            sig = (colour[i], frozenset(adj_sets[i] & alive))
            false_sig[sig].append(i)

        for sig, group in false_sig.items():
            if len(group) < 2:
                continue
            changed = True
            k = len(group)
            aut_factor *= factorial(k)

            ts_key = ("F", k, round_num)
            if ts_key not in type_size_to_colour:
                type_size_to_colour[ts_key] = next_colour
                next_colour += 1

            keep = group[0]
            colour[keep] = type_size_to_colour[ts_key]
            for rem in group[1:]:
                alive.discard(rem)
                for nb in adj_sets[rem]:
                    adj_sets[nb].discard(rem)

        true_sig: Dict[Tuple, List[int]] = defaultdict(list)
        for i in alive:
            sig = (colour[i], frozenset((adj_sets[i] & alive) | {i}))
            true_sig[sig].append(i)

        for sig, group in true_sig.items():
            if len(group) < 2:
                continue
            changed = True
            k = len(group)
            aut_factor *= factorial(k)

            ts_key = ("T", k, round_num)
            if ts_key not in type_size_to_colour:
                type_size_to_colour[ts_key] = next_colour
                next_colour += 1

            keep = group[0]
            colour[keep] = type_size_to_colour[ts_key]
            for rem in group[1:]:
                alive.discard(rem)
                for nb in adj_sets[rem]:
                    adj_sets[nb].discard(rem)

    alive_list = sorted(alive)
    reduced = Graph(directed=graph.directed, n=len(alive_list))
    new_verts = list(reduced.vertices)
    old_to_new = {alive_list[j]: new_verts[j] for j in range(len(alive_list))}

    seen_edges: Set[Tuple[int, int]] = set()
    for i in alive_list:
        for nb in adj_sets[i] & alive:
            ek = (min(i, nb), max(i, nb))
            if ek not in seen_edges:
                seen_edges.add(ek)
                reduced.add_edge(Edge(old_to_new[i], old_to_new[nb]))

    init_colouring = {}
    for j, i in enumerate(alive_list):
        init_colouring[new_verts[j]] = colour[i]

    return reduced, aut_factor, init_colouring
