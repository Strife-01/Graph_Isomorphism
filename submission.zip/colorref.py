from collections import defaultdict
from typing import List, Dict, Tuple
from graph import Graph, Vertex
from graph_io import load_graph

def set_default_colouring(graph: Graph, mode: str = "uniform") -> None:
    for v in graph:
        v.colour = v.degree if mode == "degree" else 1

def partition_vertices(vertices: List[Vertex]) -> Dict[Tuple, List[Vertex]]:
    partition: Dict[Tuple, List[Vertex]] = defaultdict(list)
    for v in vertices:
        signature = (v.colour, *sorted(n.colour for n in v.neighbours))
        partition[signature].append(v)
    return partition

def get_sorted_partition(vertices: List[Vertex]) -> List[List[Vertex]]:
    partition = partition_vertices(vertices)
    return [cell for _, cell in sorted(partition.items())]

def assign_colours_from_partition(partition: List[List[Vertex]]) -> None:
    for colour, cell in enumerate(partition):
        for v in cell:
            v.colour = colour

def basic_colorref(filename: str) -> List[Tuple[List[int], List[int], int, bool]]:
    with open(filename, "r") as file:
        graphs = load_graph(file, graph_class=Graph, read_list=True)

    all_vertices: List[Vertex] = []
    for G in graphs:
        set_default_colouring(G)
        all_vertices.extend(G)

    num_colours_per_graph = [len({v.colour for v in G}) for G in graphs]
    iterations_to_stability = [0] * len(graphs)

    global_num_colours = len({v.colour for v in all_vertices})
    iteration = 0

    while True:
        current_partition = get_sorted_partition(all_vertices)

        if global_num_colours == len(current_partition):
            break

        assign_colours_from_partition(current_partition)
        global_num_colours = len(current_partition)
        iteration += 1

        for i, G in enumerate(graphs):
            current_g_colours = len({v.colour for v in G})
            if current_g_colours > num_colours_per_graph[i]:
                num_colours_per_graph[i] = current_g_colours
                iterations_to_stability[i] = iteration

    graph_classes: Dict[Tuple, List[int]] = defaultdict(list)
    for i, G in enumerate(graphs):
        signature = tuple(sorted(v.colour for v in G))
        graph_classes[signature].append(i)

    result: List[Tuple[List[int], List[int], int, bool]] = []
    for signature, indices in graph_classes.items():
        sorted_indices = sorted(indices)

        counts: Dict[int, int] = defaultdict(int)
        for colour in signature:
            counts[colour] += 1
        sizes = sorted(counts.values())

        iters = iterations_to_stability[sorted_indices[0]]
        is_discrete = len(sizes) == sum(sizes)

        result.append((sorted_indices, sizes, iters, is_discrete))

    return sorted(result, key=lambda x: x[0][0])
