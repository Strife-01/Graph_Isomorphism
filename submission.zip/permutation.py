from __future__ import annotations
from collections import deque
from typing import Dict, List, Optional, Set, Tuple

class Permutation:

    __slots__ = ("_map", "_hash")

    def __init__(self, mapping: Optional[Dict] = None):
        if mapping is None:
            self._map: Dict = {}
        else:
            self._map = {k: v for k, v in mapping.items() if k != v}
        self._hash: Optional[int] = None

    def __call__(self, x):
        return self._map.get(x, x)

    def __mul__(self, other: Permutation) -> Permutation:
        keys = set(self._map) | set(other._map)
        return Permutation({k: self(other(k)) for k in keys})

    def inverse(self) -> Permutation:
        return Permutation({v: k for k, v in self._map.items()})

    def is_identity(self) -> bool:
        return len(self._map) == 0

    @property
    def support(self) -> Set:
        return set(self._map.keys())

    def __eq__(self, other):
        if not isinstance(other, Permutation):
            return NotImplemented
        return self._map == other._map

    def __hash__(self):
        if self._hash is None:
            self._hash = hash(frozenset(self._map.items()))
        return self._hash

    def __repr__(self):
        if self.is_identity():
            return "Permutation()"
        cycles = self._cycle_notation()
        return "".join(f"({' '.join(str(x) for x in c)})" for c in cycles)

    def _cycle_notation(self) -> List[List]:
        visited: Set = set()
        cycles: List[List] = []
        for k in sorted(self._map, key=str):
            if k in visited:
                continue
            cycle = []
            x = k
            while x not in visited:
                visited.add(x)
                cycle.append(x)
                x = self(x)
            if len(cycle) > 1:
                cycles.append(cycle)
        return cycles

IDENTITY = Permutation()

def orbit_and_transversal(generators: List[Permutation],
                          alpha) -> Tuple[Set, Dict]:
    orbit: Set = {alpha}
    transversal: Dict = {alpha: IDENTITY}
    queue: deque = deque([alpha])

    while queue:
        beta = queue.popleft()
        for g in generators:
            gamma = g(beta)
            if gamma not in orbit:
                orbit.add(gamma)
                transversal[gamma] = g * transversal[beta]
                queue.append(gamma)

    return orbit, transversal

class _StabiliserLevel:
    __slots__ = ("alpha", "orbit", "transversal", "generators")

    def __init__(self, alpha, generators: List[Permutation]):
        self.alpha = alpha
        self.generators = list(generators)
        self.orbit, self.transversal = orbit_and_transversal(
            self.generators, alpha
        )

def _build_chain(generators: List[Permutation],
                 base: List) -> List[_StabiliserLevel]:
    chain: List[_StabiliserLevel] = []
    current_gens = list(generators)

    for alpha in base:
        if not current_gens:
            break

        level = _StabiliserLevel(alpha, current_gens)
        chain.append(level)

        next_gens: List[Permutation] = []
        seen: Set[Permutation] = set()

        for beta in level.orbit:
            u_beta = level.transversal[beta]
            for g in level.generators:
                gamma = g(beta)
                u_gamma = level.transversal[gamma]
                schreier = u_gamma.inverse() * g * u_beta
                if not schreier.is_identity() and schreier not in seen:
                    seen.add(schreier)
                    next_gens.append(schreier)

        current_gens = next_gens

    return chain

def _choose_base(generators: List[Permutation],
                 elements: List) -> List:
    base = []
    moved = set()
    for g in generators:
        moved |= g.support

    for e in elements:
        if e in moved:
            base.append(e)

    return base

def group_order(generators: List[Permutation],
                elements: List) -> int:
    if not generators:
        return 1

    base = _choose_base(generators, elements)
    if not base:
        return 1

    chain = _build_chain(generators, base)

    order = 1
    for level in chain:
        order *= len(level.orbit)

    return order

def is_member(perm: Permutation,
              generators: List[Permutation],
              elements: List) -> bool:
    if perm.is_identity():
        return True
    if not generators:
        return False

    base = _choose_base(generators, elements)
    chain = _build_chain(generators, base)

    current = perm
    for level in chain:
        beta = current(level.alpha)
        if beta not in level.orbit:
            return False
        u_beta = level.transversal[beta]
        current = u_beta.inverse() * current
        if current.is_identity():
            return True

    return current.is_identity()
